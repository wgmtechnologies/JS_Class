// var productPrice = 100;
// var gst = 18;


// var productPrice = parseInt(prompt("Enter product Price"));
// var productPrice = parseFloat(prompt("Enter product Price"));
var productPrice = +prompt("Enter product Price");
var discount = +prompt("Enter Discount amt")
var gst = +prompt("Enter GST amount");

document.getElementById('productPrice').innerHTML = productPrice;
document.getElementById('discount').innerHTML = discount+"%";
document.getElementById('gst').innerHTML = gst+"%";

document.getElementById('amount').innerHTML = productPrice-(productPrice*discount)/100+((productPrice-(productPrice*discount)/100)*gst)/100

// console.log(typeof productPrice, productPrice);